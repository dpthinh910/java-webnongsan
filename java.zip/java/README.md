# java-webnongsan
Đồ án Công Nghệ Java - ĐH Công nghệ thông tin UIT
-- Hướng dẫn cài đặt
1. Cài đặt project webapplication (phải cài đặt server để chạy, có thể Apache Tomcat)
2. Source giao diện JSP nằm hết folder web trên Git. Cái này tương ứng với folder Web Page ở NetBean. Chỉ cần copy tất cả các mục ở folder web trên git đưa vào folder Web Page ở NetBean là có thể chạy được.
3. Chưa chỉnh sửa thêm file gì khác. Chỉ tác động lên folder Web Page.

